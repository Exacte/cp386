/*
detector.c

Student Name : ....
Student ID # : ....

*/

#include <string.h>
#include <stddef.h>
#include <stdio.h>

#define MAX_LINE_LENGTH 1000

/*
Any required standard libraries and your header files here
*/

void detector(FILE *fd){
    /*
        Your code here.
        You may edit the following code
    */
    char line_buffer[MAX_LINE_LENGTH];
    //int start_time, run_time, process_id, num_exchanges, exchange_time;
    //char *token;
    
    int n, m;
    //Processs first line
    fgets(line_buffer, MAX_LINE_LENGTH, fd);
    sscanf(line_buffer, "%d %d",&n, &m);
    
    //Process remaining lines
    //Hint use template code from A1 to parse each line
}
