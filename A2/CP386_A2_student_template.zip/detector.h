/*
Do not edit the contents of this file
*/
#ifndef DETECTOR
#define DETECTOR
void detector(FILE *fd);
#endif
