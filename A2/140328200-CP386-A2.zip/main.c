/*

main.c for use with dispatcher.c

Do not edit the contents of this file.
*/

#include <stdio.h>
#include <string.h>
#include "detector.h"
 
 
int main(int argc, char **argv) {
    detector( stdin );
    return 0;
}
