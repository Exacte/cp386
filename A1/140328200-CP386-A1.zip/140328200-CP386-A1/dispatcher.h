/*
Do not edit the contents of this file
*/
void dispatcher(FILE *fd, int quantum, int harddrive);
